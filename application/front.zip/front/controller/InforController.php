<?php
namespace app\front\controller;
use app\common\model\Typography as articleModel ;
use app\common\model\Typography;
use think\Controller;
use think\Request;

class InforController extends Controller 
{
    //显示专业页面

    public function major()
    {
        $data =db('typography')->alias('a')->where('delete_time','NULL')->where('files','neq','NULL')->order('id desc')->paginate(6); 
        $this->assign('afile',$data);
        return $this->fetch();
    }
    //显示学校界面

    public function school()
    {
        $data =db('typography')->alias('a')->where('delete_time','NULL')->order('id desc')->paginate(16); 
        $this->assign('sfile',$data);
       
        return $this->fetch();

    }
    //显示详细学校页面
    public function sinfo()
    {
        //id值最好从前一页的Ajax接口中获取

        $data =db('typography')->alias('a')->where('delete_time','NULL')->order('id desc')->paginate(16); 
        $this->assign('sfile',$data);
        return $this->fetch();
    }


   //下载文件
   //没实现
    public function downFile($path = ''){
    if(!$path) header("Location: /");
    download($path);
    }

   function download($file_url,$new_name=''){  
    if(!isset($file_url)||trim($file_url)==''){  
        echo '500';  
    }  
    if(!file_exists($file_url)){ //检查文件是否存在  
        echo '404';  
    } 
    $file_name=basename($file_url);  
    $file_type=explode('.',$file_url);  
    $file_type=$file_type[count($file_type)-1];  
    $file_name=trim($new_name=='')?$file_name:urlencode($new_name);  
    $file_type=fopen($file_url,'r'); //打开文件  
    //输入文件标签 
    header("Content-type: application/octet-stream");  
    header("Accept-Ranges: bytes");  
    header("Accept-Length: ".filesize($file_url));  
    header("Content-Disposition: attachment; filename=".$file_name);  
    //输出文件内容  
    echo fread($file_type,filesize($file_url));  
    fclose($file_type);
}  
}
