<?php
namespace app\front\controller;
use app\common\model\Elements as articleModel ;
use think\Controller;
use think\Request;

class ArticleController extends Controller
{
  public function show()
  {
    $id=input('id');
    $data =db('elements')->alias('a')->where('id',$id)->order('id desc')->paginate('1'); 
      $this->assign('list',$data);
      return $this->fetch();
  }
    public function index()
    {
    $art=new articleModel;
    if(request()->isPost()){
       $data=input('post.');
       $data['time']=time();
      if($art->save($data)){
        $this->success('文章上传成功','/front/user/index');
              }
          else{
             $this->error('文章上传失败','/front/user/index');
             }
        }
      return $this->fetch();
     } 

     public function edit()
     {
       $art=new articleModel();
       
       if(request()->isPost()){
         $data=input('post.');
         if($art->update($data)){
           $this->success('文章修改成功','user/index');
         }
         else{
           $this->error('文章修改失败','user/index');
         }
       }
       $id=input('id');
       $list=db('elements')->where('id',$id)->find();
       $datas = db('elements')->where('id',$id)->find();
       $this->assign(array('data'=>$datas,'list'=>$list));
        return view();
     }
 
     public function del(){
        $id=input('id');
       if(articleModel::destroy($id)){
          $this->success('文章删除成功','user/index');
       }
       else{
           $this->error('文章删除失败','user/index');
       }
     }
     
}