<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE);
return[
	'host'=>'http://thhui.wywwwxm.com/tplayout1/tp5/public/index.php',
	'oauth_stepl'=>'/admin/Oauth/OauthCode',
];
?>