<?php

namespace app\admin\controller;
use app\common\model\Elements as articleModel ;
use think\Controller;
use think\Request;

class ElementsController extends Controller
{
     public function index()
    {
    $art=new articleModel;
    if(request()->isPost()){
       $data=input('post.');
       $data['time']=time();
      if($art->save($data)){
        $this->success('文章上传成功','elements/list');
      }
        else{
        $this->error('文章上传失败','elements/list');
      }
    }
    return $this->fetch();
     } 

     public function list()
     {
         $data =db('elements')->alias('a')->where($where)->order('id desc')->paginate(3); 
         $this->assign('list',$data);
         return view();
     }
     public function show(){
      $data =db('elements')->alias('a')->where($where)->order('id desc')->paginate(2); 
      $this->assign('list',$data);
      return view();
     }

     public function edit()
    {
      $art=new articleModel();
      
      if(request()->isPost()){
        $data=input('post.');
        if($art->update($data)){
          $this->success('文章修改成功','elements/list');
        }
        else{
          $this->error('文章修改失败','elements/list');
        }
      }
      $id=input('id');
      $list=db('elements')->where('id',$id)->find();
      $this->assign(array('data'=>$datas,'list'=>$list));
       return view();
    }

    public function del(){
       $id=input('id');
      if(articleModel::destroy($id)){
         $this->success('文章删除成功','elements/list');
      }
      else{
          $this->error('文章删除失败','elements/list');
      }
    }
    
}




   