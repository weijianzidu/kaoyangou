<?php

namespace app\admin\controller;

use app\common\model\Typography;
use think\Controller;
use think\Request;

class TypographyController extends Controller
{
    // 数据添加/修改时，所使用的字段名称
    //protected $fields = ['name'];

    /**
     * 显示资源列表
     *
     * @return \think\Response
     */
    public function index()
    {
        $data =db('typography')->alias('a')->where($where)->order('id desc')->paginate(3); 
        $this->assign('list',$data);
        //$indexs = Typography::all();
        // 把数据赋值给视图
       // $this->assign('indexs', $indexs);
        // 显示视图
        return $this->fetch();
    }
    //添加院校
    public function add()
    {

    }
    //编辑院校
    public function edit()
    {
        
    }
    //删除院校
    public function del()
    {
        
    }
}
